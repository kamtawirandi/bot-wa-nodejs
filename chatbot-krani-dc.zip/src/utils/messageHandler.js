const { saveFile } = require('./fileHandler');
const { authenticateGoogleDrive, uploadFileToDrive } = require('./googleDrive');

const handleIncomingMessage = async (message) => {
    if (message.hasMedia) {
        const media = await message.downloadMedia();

        // Cek jika file yang diterima berformat ZIP
        if (media.mimetype === 'application/zip') {
            // Ambil tanggal saat ini
            const date = new Date().toISOString().split('T')[0];  // Format: YYYY-MM-DD
            const filePath = await saveFile(media, date);
            
            // Balasan profesional setelah file diterima
            const replyMessage = `
            Terima kasih! File Anda telah diterima dan sedang diproses.
            File ZIP telah disimpan dengan nama: ${media.filename}.
            Kami akan segera memprosesnya dan mengunggahnya ke Google Drive.
            `;
            message.reply(replyMessage);

            // Autentikasi dan upload ke Google Drive
            const auth = await authenticateGoogleDrive();
            await uploadFileToDrive(auth, filePath, media.filename);
        } else {
            message.reply('File yang diterima bukan file ZIP. Harap kirimkan file ZIP.');
        }
    } else {
        message.reply('Terima kasih atas pesan Anda! Jika Anda ingin mengirimkan file, pastikan itu adalah file ZIP.');
    }
};

module.exports = { handleIncomingMessage };
