const fs = require('fs');
const path = require('path');

// Fungsi untuk menyimpan file ZIP berdasarkan tanggal
const saveFile = async (media, date) => {
    const folderPath = path.join(__dirname, '../files', date);  // Folder berdasarkan tanggal
    if (!fs.existsSync(folderPath)) {
        fs.mkdirSync(folderPath, { recursive: true });
    }

    // Ambil nama file asli dari media
    const originalFileName = media.filename || `file-${Date.now()}.zip`;  // Jika nama file tidak ada, gunakan nama default

    const filePath = path.join(folderPath, originalFileName);
    fs.writeFileSync(filePath, media.data);
    console.log(`File disimpan di: ${filePath}`);
    
    return filePath;
};

module.exports = { saveFile };
