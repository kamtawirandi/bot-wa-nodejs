const cron = require('node-cron');

// Fungsi untuk menjadwalkan pengingat pagi
const scheduleMorningReminder = (client) => {
    cron.schedule('0 8 * * *', () => {
        // Dapatkan chat grup berdasarkan ID grup
        const groupId = process.env.WHATSAPP_GROUP_ID; // Ambil dari file .env
        client.getChatById(groupId).then(chat => {
            chat.sendMessage('Selamat Pagi!!!\n\n' +
  'Bapak-Bapak Mandor, mohon untuk dikirimkan file tracking unit untuk tanggal hari ini.\n\n' +
  '- Salam, "ChatBot-Automatic"');
        }).catch(err => {
            console.log('Gagal mengirim pesan ke grup:', err);
        });
    }, {
        timezone: 'Asia/Makassar'  // Atur zona waktu WITA (UTC +8)
    });
};

module.exports = { scheduleMorningReminder };
