const { google } = require('googleapis');
const fs = require('fs');
const path = require('path');
const readline = require('readline');

// Konfigurasi OAuth2 Google API
const SCOPES = ['https://www.googleapis.com/auth/drive.file']; // Akses ke file Google Drive
const TOKEN_PATH = path.join(__dirname, '../token.json'); // Tempat menyimpan token

// Autentikasi dengan OAuth2
const authenticateGoogleDrive = async () => {
    const oAuth2Client = new google.auth.OAuth2(
        process.env.GOOGLE_CLIENT_ID,  // Client ID dari Google Cloud
        process.env.GOOGLE_CLIENT_SECRET,  // Client Secret dari Google Cloud
        'http://localhost'  // Redirect URI yang digunakan
    );

    // Jika token sudah ada, gunakan token tersebut
    if (fs.existsSync(TOKEN_PATH)) {
        const credentials = JSON.parse(fs.readFileSync(TOKEN_PATH));
        oAuth2Client.setCredentials(credentials);
    } else {
        await getAccessToken(oAuth2Client); // Jika token belum ada, buat token baru
    }

    return oAuth2Client;
};

// Mengambil akses token untuk pertama kali
const getAccessToken = (oAuth2Client) => {
    return new Promise((resolve, reject) => {
        const authUrl = oAuth2Client.generateAuthUrl({
            access_type: 'offline',
            scope: SCOPES,
        });

        console.log('Authorize this app by visiting this url: ', authUrl);

        const rl = readline.createInterface({
            input: process.stdin,
            output: process.stdout,
        });

        rl.question('Enter the code from that page here: ', async (code) => {
            rl.close();

            try {
                const { tokens } = await oAuth2Client.getToken(code);
                oAuth2Client.setCredentials(tokens);
                fs.writeFileSync(TOKEN_PATH, JSON.stringify(tokens)); // Simpan token
                resolve();
            } catch (error) {
                reject(error);
            }
        });
    });
};

// Mengupload file ke Google Drive
const uploadFileToDrive = async (auth, filePath, fileName) => {
    const drive = google.drive({ version: 'v3', auth });

    const fileMetadata = {
        name: fileName,
    };

    const media = {
        body: fs.createReadStream(filePath),
    };

    try {
        const file = await drive.files.create({
            resource: fileMetadata,
            media: media,
            fields: 'id',
        });
        console.log(`File berhasil diupload ke Google Drive, ID file: ${file.data.id}`);
    } catch (error) {
        console.error('Error uploading file to Google Drive: ', error);
    }
};

module.exports = { authenticateGoogleDrive, uploadFileToDrive };
