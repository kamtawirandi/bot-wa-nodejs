const { Client, LocalAuth } = require('whatsapp-web.js');  // Import LocalAuth untuk session
const qrcode = require('qrcode-terminal');
const dotenv = require('dotenv');
const cron = require('./utils/cron');
const messageHandler = require('./utils/messageHandler');
const fs = require('fs');
const path = require('path');

dotenv.config();

const sessionPath = path.join(__dirname, '../sessions'); // Lokasi penyimpanan sesi
if (!fs.existsSync(sessionPath)) {
    fs.mkdirSync(sessionPath, { recursive: true });
}

// Menyiapkan client dengan autentikasi lokal
const client = new Client({
    authStrategy: new LocalAuth({
        clientId: 'whatsapp-session',  // Nama sesi yang digunakan
        dataPath: sessionPath,         // Lokasi penyimpanan sesi
    }),
    puppeteer: { headless: true }
});

client.on('qr', (qr) => {
    // Cetak QR Code untuk login pertama kali
    qrcode.generate(qr, { small: true });
    console.log('Scan QR Code with your phone to log in.');
});

client.on('ready', () => {
    console.log('Bot siap dan terhubung dengan WhatsApp!');
    
    // Menjalankan pengingat pagi setiap jam 08:00 WITA
    cron.scheduleMorningReminder(client);
});

// Tangani pesan masuk
client.on('message', async (message) => {
    await messageHandler.handleIncomingMessage(message);
});

client.on('group_join', (notification) => {
    console.log('New group ID:', notification.chatId);  // Menampilkan ID grup
  });
  
  client.on('message', async message => {
    if (message.isGroupMsg) {
      console.log('Group ID:', message.chat.id);  // ID grup
    }
  });
  

client.initialize();
